Gurkirat Dhatt
101211491
gurkiratdhatt@cmail.carleton.ca
1. https://youtu.be/e6Ryqra2Tsw
2. https://youtu.be/58qXY5sQoag
3. https://youtu.be/UckiclX9fq0
*Had to make 3 seperate videos becuase the screen capture would only record either the code or the program running and
not both. Sorry couldnt find a way to combine all 3 also with the xbox screen capture.
Java SDK 16.0.1
Setup Instructions:None
No issues that I am aware of
The FXMouseApplication has the main() function.
R2.4 is not done fully but attempeted in the DraggableRectangle Class
module javaFXHelloWorld {
    requires javafx.fxml;
    requires javafx.controls;

    opens com.sample;
}